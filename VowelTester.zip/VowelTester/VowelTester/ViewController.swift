//
//  ViewController.swift
//  VowelTester
//
//  Created by Kodipelly,Sravani on 1/25/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textoutlet: UITextField!
    
    @IBOutlet weak var displaylabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func buttonclicked(_ sender: UIButton) {
        //read the text
        var enteredtext = textoutlet.text!
        //check for vowel
        if (enteredtext.contains("a") || enteredtext.contains("e") || enteredtext.contains("i") || enteredtext.contains("o") || enteredtext.contains("u")){
            //display on the label
            displaylabel.text = "The enteredtext contains vowel"
        }
        else{
            displaylabel.text = "The enteredtext doesnot have vowel"
        }
    }
}

